var movieList=[];

var movietest = [];
var returncount;
var currentPage = 1;//当前页数
var maxCount = 0;//最大页数
var n = 10; //单页显示电影数
var currentMax=0;

jQuery(function($){
    showTypeMovies();
    $('.movietypeSelect').click(movietypeClick);
    $('.movielanguageSelect').click(movieLanguageClick);
    $('.movietimeSelect').click(movietimeClick);
    $('.doubanstarSelect').click(doubanstarClick);
    $('.movietype>ul>li').click(movietypeliClick);
    $('.movielanguage>ul>li').click(movielanguageliClick);
    $('.movietime>ul>li').click(movietimeliClick);
    $('.doubanstar>ul>li').click(doubanstarliClick);
    $('.submitlist').click(submitlistClick);
    $('.lovemore').click(lovemoreClick);
    $('.horrormore').click(horrormoreClick);
    $('.funnymore').click(funnymoreClick);

});
function movietypeClick(){//类型span点击，list收缩
    $('.movietype').slideToggle();
}
function movieLanguageClick(){//language span点击，list收缩
    $('.movielanguage').slideToggle();
}
function movietimeClick(){//time span点击，list收缩
    $('.movietime').slideToggle();
}
function doubanstarClick(){//doubanstar span点击，list收缩
    $('.doubanstar').slideToggle();
}
function movietypeliClick(){//类型list点击，选中分数，并在span中显示
    $('.movietypeSelect>span').text($(this).text());
    $('.movietype').slideUp();
}
function movielanguageliClick(){//电影语言list点击，选中分数，并在span中显示
    $('.movielanguageSelect>span').text($(this).text());
    $('.movielanguage').slideUp();
}
function movietimeliClick(){//时间list点击，选中分数，并在span中显示
    $('.movietimeSelect>span').text($(this).text());
    $('.movietime').slideUp();
}
function doubanstarliClick(){//豆瓣评分list点击，选中分数，并在span中显示
    $('.doubanstarSelect>span').text($(this).text());
    $('.doubanstar').slideUp();
}
function lovemoreClick(){
    getMoreMovies(100,'爱情');
}
function horrormoreClick(){
    getMoreMovies(100,'惊悚');
}
function funnymoreClick(){
    getMoreMovies(100,'喜剧');
}
function submitlistClick(){ //提交请求，发送主题参数
   var typeQ=  $('.movietypeSelect>span').text();
   var languageQ =  $('.movielanguageSelect>span').text();
   var timeQ =  $('.movietimeSelect>span').text();
   var doubanstarQ =  $('.doubanstarSelect>span').text();
    getAskMovies(100,typeQ,languageQ,timeQ,doubanstarQ);

}

function getAskMovies(n,typeQ,languageQ,timeQ,doubanstarQ){//根据参数返回主题推荐，并在回调函数中进行显示
    $.ajax({
        type: "get",
        url: "http://192.168.2.113:3000/theme?num="+n+"&myear="+timeQ+"&mtype="+typeQ+"&mlanguage="+languageQ+"&mscore="+doubanstarQ,
        async: false, // 设置为同步，true为异步
        success: function (data) {
            movietest = data;
            returncount = data.length;
            maxCount = Math.floor(returncount/10);
            if (data.length<10){
                $('#MovieList>p:gt('+(data.length-1)+')').hide();
                $('#MovieList>table:gt('+(data.length-1)+')').hide();

            }
            $('.main').hide();
            $('.recommendlist').show();
            showMoveList();//recommendlist显示推荐结果

        }
    });
}
function getMoreMovies(n,mtype){//获得随机n部电影
    $.ajax({
        type: "get",
        url: "http://192.168.2.113:3000/themeone?num="+n+"&mtype="+mtype,
        async: false, // 设置为同步，true为异步
        success: function (data) {
            movietest = data;
            returncount = data.length;
            maxCount = Math.floor(returncount/10);
            if (data.length<10){
                $('#MovieList>p:gt('+(data.length-1)+')').hide();
                $('#MovieList>table:gt('+(data.length-1)+')').hide();

            }
            $('.main').hide();
            $('.recommendlist').show();
            showMoveList();//recommendlist显示推荐结果
        }
    });
}
function showTypeMovies(){ //显示一开始的三个类别，定义数据矩阵,然后分别初始化

    var lovemovies =[{
        "douban_movie_id": "24748854",
        "douban_movie_name": "极品基老伴 第二季 Vicious Season 2",
        "douban_movie_director": "埃德·拜\r",
        "douban_movie_actor": "伊恩·麦克莱恩 / 德里克·雅各比 / 弗朗西斯·德·拉·图瓦\r",
        "douban_movie_class": "喜剧 / 爱情 / 同性\r",
        "douban_movie_language": "英语\r",
        "douban_movie_releasetime": "NULL",
        "douban_movie_time": "25分钟\r",
        "douban_movie_othername": "基阳红\r",
        "douban_movie_url": "http://movie.douban.com/subject/24748854/?from=tag_all",
        "imdb_movie_url": "http://www.imdb.com/title/tt3464876",
        "douban_movie_imgurl": "http://img3.douban.com/view/movie_poster_cover/spst/public/p2186847242.jpg",
        "douban_movie_shortcomment": 375,
        "douban_movie_questioncomment": null,
        "douban_movie_longcomment": 3,
        "douban_movie_talknum": null,
        "douban_movie_lookedman": 2737,
        "douban_movie_wantlookman": 1508,
        "douban_movie_score": "9.5",
        "douban_movie_scorepeople": 2496,
        "douban_5scorepercent": "78.1",
        "douban_4scorepercent": "18.4",
        "douban_3scorepercent": "2.9",
        "douban_2scorepercent": "0.4",
        "douban_1scorepercent": "0.1",
        "douban_movie_abstract": " 《极品基老伴》主演雅各比爵士昨天在BAFTA典礼上无意透露了该剧续订第2季的消息。搞笑的是他接受采访的腔调居然延续了剧中角色的风格：“他（麦克莱恩）跑去拍电影了啦，现在没空——让上帝诅咒他！直到明年5月我们才会再这么来一次。”《基老伴》在ITV台播出后大受好评，刚提前完成今年圣诞集的拍摄。",
        "douban_movie_place": "英国\r",
        "douban_movie_year": "2015"
    },
        {
            "douban_movie_id": "25884484",
            "douban_movie_name": "波尔达克 第一季 Poldark Season 1",
            "douban_movie_director": "爱德华·巴瑟杰特\r",
            "douban_movie_actor": "艾丹·特纳 / 埃莉诺·汤姆林森 / 比蒂·埃德尼 / 菲尔·戴维斯\r",
            "douban_movie_class": "剧情 / 爱情 / 历史\r",
            "douban_movie_language": "英语\r",
            "douban_movie_releasetime": "NULL",
            "douban_movie_time": "60分钟\r",
            "douban_movie_othername": "波达克\r",
            "douban_movie_url": "http://movie.douban.com/subject/25884484/?from=tag_all",
            "imdb_movie_url": "http://www.imdb.com/title/tt3636060",
            "douban_movie_imgurl": "http://img4.douban.com/view/movie_poster_cover/spst/public/p2231294596.jpg",
            "douban_movie_shortcomment": 111,
            "douban_movie_questioncomment": null,
            "douban_movie_longcomment": 1,
            "douban_movie_talknum": null,
            "douban_movie_lookedman": 165,
            "douban_movie_wantlookman": 295,
            "douban_movie_score": "7.8",
            "douban_movie_scorepeople": 321,
            "douban_5scorepercent": "25.8",
            "douban_4scorepercent": "44.9",
            "douban_3scorepercent": "25.8",
            "douban_2scorepercent": "1.8",
            "douban_1scorepercent": "1.8",
            "douban_movie_abstract": " BBC曾改编过《Poldark》系列，原版剧集首播于1975-1977年间，共播出两季，Robin Ellis曾在剧中扮演英国军官Ross Poldark。 \r\n 在原著中，主人公Ross Poldark经历了美国独立战争，战后回到了家乡康沃尔郡，此时他发现自己的未婚妻Elizabeth Chynoweth以为自己已经阵亡，便与堂兄弟Francis Poldark订婚。Ross为了生计，重新开发了家族锡矿。若干年后，他释怀了对Elizabeth的旧爱，迎娶了女仆Demelza Carne。此时Elizabeth已成了寡妇，改嫁给了Ross的劲敌George Warleggan。 \r\n 《Poldark》系列共有12本，前七本描写Ross Poldark等人物的故事，后七本则描写主要角色后代的故事。",
            "douban_movie_place": "英国\r",
            "douban_movie_year": "2015"
        },
        {
            "douban_movie_id": "24716045",
            "douban_movie_name": "远离尘嚣 Far From the Madding Crowd",
            "douban_movie_director": "托马斯·温特伯格\r",
            "douban_movie_actor": "凯瑞·穆里根 / 马提亚斯·修奈尔 / 麦克·辛 / 汤姆·斯图里奇 / 朱诺·坦普尔 / 更多...\r",
            "douban_movie_class": "剧情 / 爱情\r",
            "douban_movie_language": "英语\r",
            "douban_movie_releasetime": "2015-05-01(美国/英国)\r",
            "douban_movie_time": "119分钟\r",
            "douban_movie_othername": "疯恋佳人(港) / 远离尘嚣：珍爱相随(台)\r",
            "douban_movie_url": "http://movie.douban.com/subject/24716045/?from=tag_all",
            "imdb_movie_url": "http://www.imdb.com/title/tt2935476",
            "douban_movie_imgurl": "http://img3.douban.com/view/movie_poster_cover/spst/public/p2235684794.jpg",
            "douban_movie_shortcomment": 238,
            "douban_movie_questioncomment": null,
            "douban_movie_longcomment": 8,
            "douban_movie_talknum": null,
            "douban_movie_lookedman": 409,
            "douban_movie_wantlookman": 3147,
            "douban_movie_score": "7.4",
            "douban_movie_scorepeople": 351,
            "douban_5scorepercent": "13.5",
            "douban_4scorepercent": "47.9",
            "douban_3scorepercent": "32.2",
            "douban_2scorepercent": "6.1",
            "douban_1scorepercent": "0.3",
            "douban_movie_abstract": " 在维多利亚时代，美丽女孩芭丝谢芭（凯瑞·穆里根 Carey Mulligan 饰）来到一个远离尘嚣的乡村，继承叔叔的遗产。她的坚毅独立，她的自信气质，使三个男人为她倾倒。他们分别是俊朗敦厚的牧羊人加布尔（马提亚斯·修奈尔 Matthias Schoenaerts 饰）、 品味成熟的贵族（麦克·辛 Michael Sheen 饰）以及狂野鲁莽的军官（汤姆·斯图里奇 Tom Sturridge 饰）。三人都真挚地爱着芭丝谢芭，而她会做出怎样的选择? \r\n 影片根据英国著名小说家托马斯·哈代成名作《远离尘嚣》改编。",
            "douban_movie_place": "英国 / 美国\r",
            "douban_movie_year": "2015"
        },
        {
            "douban_movie_id": "21442760",
            "douban_movie_name": "最长的旅程 The Longest Ride",
            "douban_movie_director": "小乔治·提尔曼\r",
            "douban_movie_actor": "布丽特·罗伯森 / 斯科特·伊斯特伍德 / 阿伦·阿尔达 / 杰克·休斯顿 / 奥娜·卓别林 / 更多...\r",
            "douban_movie_class": "剧情 / 爱情\r",
            "douban_movie_language": "英语\r",
            "douban_movie_releasetime": "2015-04-10(美国)\r",
            "douban_movie_time": "139分钟\r",
            "douban_movie_othername": "最长的行程 / 爱情没有终点(台)\r",
            "douban_movie_url": "http://movie.douban.com/subject/21442760/?from=tag_all",
            "imdb_movie_url": "http://www.imdb.com/title/tt2726560",
            "douban_movie_imgurl": "http://img3.douban.com/view/movie_poster_cover/spst/public/p2218476421.jpg",
            "douban_movie_shortcomment": 100,
            "douban_movie_questioncomment": null,
            "douban_movie_longcomment": 4,
            "douban_movie_talknum": null,
            "douban_movie_lookedman": 206,
            "douban_movie_wantlookman": 884,
            "douban_movie_score": "7.5",
            "douban_movie_scorepeople": 176,
            "douban_5scorepercent": "20.6",
            "douban_4scorepercent": "43.1",
            "douban_3scorepercent": "26.9",
            "douban_2scorepercent": "8.1",
            "douban_1scorepercent": "1.3",
            "douban_movie_abstract": " 职业牛仔卢克（斯科特·伊斯特伍德 Scott Eastwood 饰）和大学生苏菲亚（布丽特·罗伯森 Britt Robertson 饰）在一次牛仔竞技比赛中相遇，两人一见倾心迅速坠入爱河。然而，身处两个不同世界的他们，对未来和理想都有许多冲突，两人多舛的爱情也处处充满挑战。在一次意外中他们救了一位老人伊拉（阿伦·阿尔达 Alan Alda 饰），得知老人与他已故妻子露丝（奥娜·卓别林 Oona Chaplin 饰）之间动人的爱情故事后，他们深受鼓舞，这能否让他们跨越重重阻碍，共同迎向美好的未来……",
            "douban_movie_place": "美国\r",
            "douban_movie_year": "2015"
        },
        {
            "douban_movie_id": "6048838",
            "douban_movie_name": "爱森斯坦在瓜纳华托 Eisenstein in Guanajuato",
            "douban_movie_director": "彼得·格林纳威\r",
            "douban_movie_actor": "斯特里奥·萨万特 / 埃尔默·拜克 / 玛雅·扎帕塔 / Lisa Owen\r",
            "douban_movie_class": "喜剧 / 爱情 / 传记 / 历史\r",
            "douban_movie_language": "英语 / 西班牙语\r",
            "douban_movie_releasetime": "2015-02-11(柏林电影节) / 2015-07-08(法国)\r",
            "douban_movie_time": "105分钟\r",
            "douban_movie_othername": "愛森斯坦萬萬歲(港)\r",
            "douban_movie_url": "http://movie.douban.com/subject/6048838/?from=tag_all",
            "imdb_movie_url": "http://www.imdb.com/title/tt1702429",
            "douban_movie_imgurl": "http://img3.douban.com/view/movie_poster_cover/spst/public/p2226645382.jpg",
            "douban_movie_shortcomment": 66,
            "douban_movie_questioncomment": null,
            "douban_movie_longcomment": 2,
            "douban_movie_talknum": null,
            "douban_movie_lookedman": 127,
            "douban_movie_wantlookman": 1253,
            "douban_movie_score": "7.7",
            "douban_movie_scorepeople": 96,
            "douban_5scorepercent": "22.8",
            "douban_4scorepercent": "44.6",
            "douban_3scorepercent": "26.1",
            "douban_2scorepercent": "5.4",
            "douban_1scorepercent": "1.1",
            "douban_movie_abstract": " 1931年，苏联导演谢尔盖•爱森斯坦到瓜纳华托拍摄他的片子《墨西哥万岁》。在那里，他接触到了全新的文化以及他们对死亡的态度;他也发现了另一种改变—对于他自己。彼得•格林纳威把爱森斯坦刻画成一个古怪的艺术家，同时作为一个国际上著名的明星导演来到墨西哥，志得意满。然而在墨西哥，他却陷入困境，因为和他的投资者，小说家厄普顿•辛克莱尔（Upton Sinclair）相处困难。同时，他也在这块兼具欢乐和危险的异国他乡，开始重新评估他的祖国和斯大林主义的社会制度。这样的心路历程，使他经历了从电影理论家转变成关心人类状况的艺术家。在他的镜头下，墨西哥文化中的一些符号，印记，宗教和非宗教的标志都获得全新的诠释。 \r\n 电影使用了大量的特写镜头，多画面镜头以及戏剧性的蒙太奇—-所有这些都是为了表现自认为是魔术小丑的这位大人物的转变——格林纳威精妙的利用并且修改了爱森斯坦的电...",
            "douban_movie_place": "荷兰 / 墨西哥 / 芬兰 / 比利时 / 法国\r",
            "douban_movie_year": "2015"
        }];

    var horrormovies = [{
        "douban_movie_id": "6846893",
        "douban_movie_name": "超能查派 Chappie",
        "douban_movie_director": "尼尔·布洛姆坎普\r",
        "douban_movie_actor": "休·杰克曼 / 西格妮·韦弗 / 沙尔托·科普雷 / 戴夫·帕特尔 / 忍者 / 更多...\r",
        "douban_movie_class": "动作 / 科幻 / 惊悚\r",
        "douban_movie_language": "英语\r",
        "douban_movie_releasetime": "2015-05-08(中国大陆) / 2015-03-06(美国)\r",
        "douban_movie_time": "119分钟(中国大陆) / 120分钟(美国)\r",
        "douban_movie_othername": "超人类：卓比(港) / 成人世界(台) / 查皮 / 伙伴\r",
        "douban_movie_url": "http://movie.douban.com/subject/6846893/?from=tag_all",
        "imdb_movie_url": "http://www.imdb.com/title/tt1823672",
        "douban_movie_imgurl": "http://img4.douban.com/view/movie_poster_cover/spst/public/p2240110789.jpg",
        "douban_movie_shortcomment": 19344,
        "douban_movie_questioncomment": null,
        "douban_movie_longcomment": 270,
        "douban_movie_talknum": null,
        "douban_movie_lookedman": 49534,
        "douban_movie_wantlookman": 9660,
        "douban_movie_score": "7.2",
        "douban_movie_scorepeople": 44094,
        "douban_5scorepercent": "15.2",
        "douban_4scorepercent": "39.9",
        "douban_3scorepercent": "36.0",
        "douban_2scorepercent": "7.0",
        "douban_1scorepercent": "1.9",
        "douban_movie_abstract": " 故事发生在2016年的南非约翰内斯堡，为了应对不断攀升的犯罪率，某大型武器公司开发了全机械警察部队。他们将机械警察批量生产并投入使用，在打击犯罪方面取得了令人瞩目的效果。作为开发人员之一，程序员迪恩（戴夫·帕特尔 Dev Patel 饰）一直致力于制造出完全的人工智能机器人。直到某天，他的研究取得突破性进展，可是并未得到老板米歇尔·布莱德利（西格妮·韦弗 Sigourney Weaver 饰）的支持。不甘心失败的迪恩偷偷将一台不久前被打坏的机械警察带出公司，准备完善他的研究，谁知半路被三名匪徒劫持。在匪徒的威胁下，迪恩将22号写入全新系统。 \r\n 22号以“查派”的名字重生，它的诞生即将改变许多人的命运……",
        "douban_movie_place": "美国 / 墨西哥 / 南非\r",
        "douban_movie_year": "2015"
    },
        {
            "douban_movie_id": "25823412",
            "douban_movie_name": "纸牌屋 第三季 House of Cards Season 3",
            "douban_movie_director": "约翰·大卫·科尔斯 / 詹姆斯·弗雷 / Tucker Gates / 约翰·达尔 / 罗宾·怀特 / 阿格涅丝卡·霍兰\r",
            "douban_movie_actor": "凯文·史派西 / 罗宾·怀特 / 莫莉·帕克 / 迈克尔·凯利 / 雷切尔·布罗斯纳安 / 更多...\r",
            "douban_movie_class": "剧情 / 惊悚\r",
            "douban_movie_language": "英语\r",
            "douban_movie_releasetime": "NULL",
            "douban_movie_time": "58分钟\r",
            "douban_movie_othername": "众议院要人\r",
            "douban_movie_url": "http://movie.douban.com/subject/25823412/?from=tag_all",
            "imdb_movie_url": "http://www.imdb.com/title/tt3513862",
            "douban_movie_imgurl": "http://img3.douban.com/view/movie_poster_cover/spst/public/p2226185451.jpg",
            "douban_movie_shortcomment": 6708,
            "douban_movie_questioncomment": null,
            "douban_movie_longcomment": 144,
            "douban_movie_talknum": null,
            "douban_movie_lookedman": 2177,
            "douban_movie_wantlookman": 20242,
            "douban_movie_score": "8.4",
            "douban_movie_scorepeople": 18456,
            "douban_5scorepercent": "37.5",
            "douban_4scorepercent": "44.6",
            "douban_3scorepercent": "16.5",
            "douban_2scorepercent": "1.2",
            "douban_1scorepercent": "0.2",
            "douban_movie_abstract": " 尽管《纸牌屋》（House of Cards）第二季下周才会开播，但一些剧组成员已经开始展望第三季了。 \r\n 本周二当主演罗宾·怀特（Robin Wright ）被问道是否有兴趣继续出演为其赢得金球奖的角色克莱尔·安德伍德（Claire Underwood）——被任命为新一任副总统的弗兰克·安德伍德（Frank Underwood）的妻子时，她回答说：“当然，放马过来吧。” \r\n 怀特继续说道：“我们很快就会开始拍摄第三季。”尽管她称尚未看过第二季之后的剧本。 \r\n 之后Netflix电视台的代表确认了该剧已续订第三季的消息。 \r\n 《纸牌屋》第二季将于2月14日周五在Netflix台播出。",
            "douban_movie_place": "美国\r",
            "douban_movie_year": "2015"
        },
        {
            "douban_movie_id": "25884541",
            "douban_movie_name": "汉尼拔 第三季 Hannibal Season 3",
            "douban_movie_director": "大卫·斯雷德 / 文森佐·纳塔利 / 尼尔·马歇尔\r",
            "douban_movie_actor": "麦斯·米科尔森 / 休·丹西 / 理查德·阿米蒂奇 / 卡洛琳·达芙娜 / 劳伦斯·菲什伯恩 / 更多...\r",
            "douban_movie_class": "剧情 / 惊悚 / 犯罪\r",
            "douban_movie_language": "英语\r",
            "douban_movie_releasetime": "NULL",
            "douban_movie_time": "45分钟\r",
            "douban_movie_othername": "NULL",
            "douban_movie_url": "http://movie.douban.com/subject/25884541/?from=tag_all",
            "imdb_movie_url": "http://www.imdb.com/title/tt3724578",
            "douban_movie_imgurl": "http://img3.douban.com/view/movie_poster_cover/spst/public/p2241793984.jpg",
            "douban_movie_shortcomment": 205,
            "douban_movie_questioncomment": null,
            "douban_movie_longcomment": 12,
            "douban_movie_talknum": null,
            "douban_movie_lookedman": 1557,
            "douban_movie_wantlookman": 606,
            "douban_movie_score": "9.1",
            "douban_movie_scorepeople": 1083,
            "douban_5scorepercent": "67.4",
            "douban_4scorepercent": "23.7",
            "douban_3scorepercent": "6.9",
            "douban_2scorepercent": "1.3",
            "douban_1scorepercent": "0.7",
            "douban_movie_abstract": " 汉尼拔在佛罗伦萨逍遥度日；Bedelia假扮汉尼拔妻子并逐渐黑化；威尔伤了汉尼拔的心；反派\"牙仙\"红龙终于登场。",
            "douban_movie_place": "美国\r",
            "douban_movie_year": "2015"
        },
        {
            "douban_movie_id": "26022254",
            "douban_movie_name": "平凡的谎言 Ordinary Lies",
            "douban_movie_director": "John McKay / Juliet May\r",
            "douban_movie_actor": "Max Beesley / Michelle Keegan / Jason Manford / Mackenzie Crook / Jo Joyner / 更多...\r",
            "douban_movie_class": "剧情 / 惊悚\r",
            "douban_movie_language": "英语\r",
            "douban_movie_releasetime": "NULL",
            "douban_movie_time": "60分钟\r",
            "douban_movie_othername": "NULL",
            "douban_movie_url": "http://movie.douban.com/subject/26022254/?from=tag_all",
            "imdb_movie_url": "http://www.imdb.com/title/tt4273282",
            "douban_movie_imgurl": "http://img4.douban.com/view/movie_poster_cover/spst/public/p2234967528.jpg",
            "douban_movie_shortcomment": 31,
            "douban_movie_questioncomment": null,
            "douban_movie_longcomment": 0,
            "douban_movie_talknum": null,
            "douban_movie_lookedman": 22,
            "douban_movie_wantlookman": 78,
            "douban_movie_score": "7.7",
            "douban_movie_scorepeople": 80,
            "douban_5scorepercent": "28.6",
            "douban_4scorepercent": "34.3",
            "douban_3scorepercent": "34.3",
            "douban_2scorepercent": "1.4",
            "douban_1scorepercent": "1.4",
            "douban_movie_abstract": " We all tell little white lies everyday, be it for self-protection, success or love. But what happens when a spur-of-the-moment mistruth snowballs out of hand? Will the liar get away with it, or will the lie inevitably come undone, to devastating effect? \r\n Set on the shopfloor and in the offices of a motor showroom, Ordinary Lies tells the story of how desperation can lead to dras...",
            "douban_movie_place": "英国\r",
            "douban_movie_year": "2015"
        },
        {
            "douban_movie_id": "5320649",
            "douban_movie_name": "高堡奇人 The Man in the High Castle",
            "douban_movie_director": "大卫·塞梅尔\r",
            "douban_movie_actor": "艾莉克莎·黛沃洛斯 / 鲁珀特·伊文斯 / 卢克·克莱恩坦克 / DJ·考尔斯 / 乔尔·德·拉·冯特 / 更多...\r",
            "douban_movie_class": "剧情 / 科幻 / 惊悚\r",
            "douban_movie_language": "英语\r",
            "douban_movie_releasetime": "NULL",
            "douban_movie_time": "NULL",
            "douban_movie_othername": "NULL",
            "douban_movie_url": "http://movie.douban.com/subject/5320649/?from=tag_all",
            "imdb_movie_url": "http://www.imdb.com/title/tt1740299",
            "douban_movie_imgurl": "http://img4.douban.com/view/movie_poster_cover/spst/public/p2222388497.jpg",
            "douban_movie_shortcomment": 176,
            "douban_movie_questioncomment": null,
            "douban_movie_longcomment": 3,
            "douban_movie_talknum": null,
            "douban_movie_lookedman": 464,
            "douban_movie_wantlookman": 476,
            "douban_movie_score": "7.9",
            "douban_movie_scorepeople": 572,
            "douban_5scorepercent": "26.3",
            "douban_4scorepercent": "47.6",
            "douban_3scorepercent": "21.9",
            "douban_2scorepercent": "3.2",
            "douban_1scorepercent": "1.0",
            "douban_movie_abstract": " 亚马逊发布了13部原创剧的试播剧之一。 \r\n 《高堡奇人》讲述了一个替代现实故事，德国和日本打赢了二战，美国被德国和日本统治，希特勒感染了梅毒，德国开始征服太阳系，而一位高堡奇人却在创作一本书讲述美国打赢二战的故事。",
            "douban_movie_place": "美国\r",
            "douban_movie_year": "2015"
        }];
    var funnymovies = [{
        "douban_movie_id": "24405378",
        "douban_movie_name": "王牌特工：特工学院 Kingsman: The Secret Service",
        "douban_movie_director": "马修·沃恩\r",
        "douban_movie_actor": "塔伦·埃格顿 / 科林·费尔斯 / 塞缪尔·杰克逊 / 迈克尔·凯恩 / 马克·斯特朗 / 更多...\r",
        "douban_movie_class": "喜剧 / 动作 / 犯罪 / 冒险\r",
        "douban_movie_language": "英语 / 阿拉伯语 / 瑞典语\r",
        "douban_movie_releasetime": "2015-03-27(中国大陆) / 2014-12-13(BNAT电影节) / 2015-01-29(英国)\r",
        "douban_movie_time": "125分钟(中国大陆) / 129分钟(美国)\r",
        "douban_movie_othername": "皇家特工：间谍密令(港) / 金牌特务(台) / 金牌特工 / 特勤局 / 王的男人之秘密服务(豆友译名) / The Secret Service\r",
        "douban_movie_url": "http://movie.douban.com/subject/24405378/?from=tag_all",
        "imdb_movie_url": "http://www.douban.com/special/colin",
        "douban_movie_imgurl": "http://img4.douban.com/view/movie_poster_cover/spst/public/p2231932406.jpg",
        "douban_movie_shortcomment": 82791,
        "douban_movie_questioncomment": null,
        "douban_movie_longcomment": 599,
        "douban_movie_talknum": null,
        "douban_movie_lookedman": 202799,
        "douban_movie_wantlookman": 36023,
        "douban_movie_score": "8.5",
        "douban_movie_scorepeople": 182338,
        "douban_5scorepercent": "43.4",
        "douban_4scorepercent": "42.2",
        "douban_3scorepercent": "12.9",
        "douban_2scorepercent": "1.2",
        "douban_1scorepercent": "0.4",
        "douban_movie_abstract": " 哈里（科林·费斯 Colin Firth 饰）是英国秘密特工组织金士曼中的一员，某次行动中，他的战友不幸牺牲，哈里将一枚徽章和一个电话号码交给了战友年幼的小儿子艾格西（亚历克斯·尼科洛夫 Alex Nikolov 饰），叮嘱他将来如果遇到了什么麻烦可以拨打这个号码，然而，这样的机会只能使用一次。 \r\n 一晃眼十七年过去，破碎的家庭让艾格西（塔伦·埃格顿 Taron Egerton 饰）成长为了一个整日无所事事的小混混，某日，因为违反交通规则而遭到逮捕的艾格西使用了手中珍贵的号码，赶来的哈里在艾格西玩世不恭的外表之下发现了他善良的本质和极高的天赋，于是，哈里决定将艾格西培养成为新一代金士曼，他们需要共同面对的是强大而又邪恶的亿万富翁瓦伦丁（塞缪尔·杰克逊 Samuel L. Jackson 饰）。",
        "douban_movie_place": "英国 / 美国\r",
        "douban_movie_year": "2015"
    },
        {
            "douban_movie_id": "10827341",
            "douban_movie_name": "疯狂外星人 Home",
            "douban_movie_director": "蒂姆·约翰逊\r",
            "douban_movie_actor": "吉姆·帕森斯 / 蕾哈娜 / 史蒂夫·马丁 / 詹妮弗·洛佩兹 / 马特·琼斯 / 更多...\r",
            "douban_movie_class": "喜剧 / 科幻 / 动画 / 冒险\r",
            "douban_movie_language": "英语\r",
            "douban_movie_releasetime": "2015-04-24(中国大陆) / 2015-03-07(博尔德电影节) / 2015-03-27(美国)\r",
            "douban_movie_time": "94分钟\r",
            "douban_movie_othername": "家园 / 无敌安乐窝(港) / 好家在一起(台) / 斯麦克节快乐 / Happy Smekday! / The True Meaning of Smekday\r",
            "douban_movie_url": "http://movie.douban.com/subject/10827341/?from=tag_all",
            "imdb_movie_url": "http://www.imdb.com/title/tt2224026",
            "douban_movie_imgurl": "http://img4.douban.com/view/movie_poster_cover/spst/public/p2235609577.jpg",
            "douban_movie_shortcomment": 9869,
            "douban_movie_questioncomment": null,
            "douban_movie_longcomment": 62,
            "douban_movie_talknum": null,
            "douban_movie_lookedman": 23299,
            "douban_movie_wantlookman": 6064,
            "douban_movie_score": "7.3",
            "douban_movie_scorepeople": 20739,
            "douban_5scorepercent": "16.9",
            "douban_4scorepercent": "40.0",
            "douban_3scorepercent": "36.5",
            "douban_2scorepercent": "5.5",
            "douban_1scorepercent": "1.0",
            "douban_movie_abstract": " 远在宇宙另一端的波波星人因为不堪忍受瓜星人的侵掠，于是举族远迁，将蔚蓝的地球视为他们新的定居点。在颟顸的领袖的指挥下，波波星人将人类驱逐到澳大利亚一处专门修建的定居点，还美其名曰与人类和平共处。绰号“小费”的女孩格莱图蒂•图奇是城市中唯一的落网者，她思念被抓走的母亲，于是带着爱猫驱车寻找母亲的下落。半路上小费遭遇了一名波波星人小欧，小欧是一个令同族人唯恐避之不及的麻烦所在，他不久前用手中的仪器发送了乔迁派对的邀请，谁知其中一条群发给了瓜星人，他由此被同类视作叛徒遭到追捕。 \r\n 类似的遭遇让小费和小欧坐上同一辆车，他们由此踏上惊险的旅程，期间则得知瓜星人追逐波波星人的原因……",
            "douban_movie_place": "美国\r",
            "douban_movie_year": "2015"
        },
        {
            "douban_movie_id": "25802407",
            "douban_movie_name": "功之怒 Kung Fury",
            "douban_movie_director": "大卫·桑德伯格\r",
            "douban_movie_actor": "大卫·桑德伯格 / 乔玛·塔科内 / Steven Chew / Leopold Nilsson / Andreas Cahling / 更多...\r",
            "douban_movie_class": "喜剧 / 动作 / 科幻 / 短片 / 奇幻\r",
            "douban_movie_language": "英语 / 瑞典语 / 德语\r",
            "douban_movie_releasetime": "2015-05-22(戛纳电影节) / 2015-05-28(瑞典)\r",
            "douban_movie_time": "31分钟\r",
            "douban_movie_othername": "功夫怒汉 / 功夫之怒 / 愤怒功夫\r",
            "douban_movie_url": "http://movie.douban.com/subject/25802407/?from=tag_all",
            "imdb_movie_url": "http://www.imdb.com/title/tt3472226",
            "douban_movie_imgurl": "http://img3.douban.com/view/movie_poster_cover/spst/public/p2246956602.jpg",
            "douban_movie_shortcomment": 5006,
            "douban_movie_questioncomment": null,
            "douban_movie_longcomment": 9,
            "douban_movie_talknum": null,
            "douban_movie_lookedman": 12072,
            "douban_movie_wantlookman": 3286,
            "douban_movie_score": "7.9",
            "douban_movie_scorepeople": 10246,
            "douban_5scorepercent": "33.0",
            "douban_4scorepercent": "39.2",
            "douban_3scorepercent": "21.4",
            "douban_2scorepercent": "4.0",
            "douban_1scorepercent": "2.5",
            "douban_movie_abstract": " 《KungFury》（中译名《功之怒》）是一部以80年代警匪片为背景，并包含了功夫、机器人、恐龙、纳粹、雷神、维京海盗、时空穿越、80年代电子游戏、80年代动作片、变种犀牛人等等等等元素于一体的名副其实的神片。众多的复古元素、高大上的特效、合不拢的脑洞和全程高能，好听到爆的80年代电子音乐，绝对让你在看完预告片后欲罢不能。 \r\n 本片是David Sandberg自导自演的一部短片，2013年12月他在Kickstarter上发起集资，集资目标是20万美元，最终筹集到630,019美元， 但因为没有达到100万美元的长片集资目标，所以最后选择制作成30分钟的短片。",
            "douban_movie_place": "瑞典\r",
            "douban_movie_year": "2015"
        },
        {
            "douban_movie_id": "11808948",
            "douban_movie_name": "海绵宝宝历险记：海绵出水 The SpongeBob Movie: Sponge Out of Water",
            "douban_movie_director": "Paul Tibbitt\r",
            "douban_movie_actor": "安东尼奥·班德拉斯 / Eric Bauza / 蒂姆·康威 / 埃迪·狄森 / 罗伯·鲍森 / 更多...\r",
            "douban_movie_class": "喜剧 / 动画 / 冒险\r",
            "douban_movie_language": "英语\r",
            "douban_movie_releasetime": "2015-02-06(美国)\r",
            "douban_movie_time": "92分钟\r",
            "douban_movie_othername": "海绵宝宝：海陆大出击(台) / 海绵宝宝历险记2 / 海绵宝宝3D / SpongeBob SquarePants 2 / The SpongeBob SquarePants Movie 2\r",
            "douban_movie_url": "http://movie.douban.com/subject/11808948/?from=tag_all",
            "imdb_movie_url": "http://www.imdb.com/title/tt2279373",
            "douban_movie_imgurl": "http://img3.douban.com/view/movie_poster_cover/spst/public/p2186978440.jpg",
            "douban_movie_shortcomment": 3143,
            "douban_movie_questioncomment": null,
            "douban_movie_longcomment": 6,
            "douban_movie_talknum": null,
            "douban_movie_lookedman": 8457,
            "douban_movie_wantlookman": 3332,
            "douban_movie_score": "7.2",
            "douban_movie_scorepeople": 7189,
            "douban_5scorepercent": "17.4",
            "douban_4scorepercent": "34.9",
            "douban_3scorepercent": "38.9",
            "douban_2scorepercent": "7.3",
            "douban_1scorepercent": "1.6",
            "douban_movie_abstract": " 围绕蟹黄堡的神秘配方，痞老板和蟹老板展开了新一轮的战争。虽然海绵宝宝成功挫败痞老板的猛烈攻势，但是却依然中了对方的诡计。关键时刻，配方凭空消失，直接后果便是导致没人能再做出蟹黄堡。对于日常极度依赖蟹黄堡的比奇堡的居民来说，这一消息无异于晴天霹雳。小镇的宁静荡然无存，海底世界陷入末世般的混乱与动荡之中。由于搭救了痞老板，海绵宝宝被大家当作叛徒对待。危机时刻，海绵宝宝、派大星、痞老板、蟹老板、松鼠珊蒂、章鱼哥得以穿越时空，并顺着蟹黄堡的香味来到了人头攒动的沙滩上。 在那里他们遇见了利用诡计偷走秘方的胡子海盗（安东尼奥·班德拉斯 Antonio Banderas 饰），于是一场蟹黄堡的攻防战由此展开……",
            "douban_movie_place": "美国\r",
            "douban_movie_year": "2015"
        },
        {
            "douban_movie_id": "24397586",
            "douban_movie_name": "小羊肖恩 Shaun the Sheep Movie",
            "douban_movie_director": "马克·伯顿 / 理查德·斯塔扎克\r",
            "douban_movie_actor": "贾斯汀·弗莱彻 / 约翰·斯帕克斯 / 欧米德·吉亚李利 / 理查德·韦伯 / 凯特·哈伯 / 更多...\r",
            "douban_movie_class": "喜剧 / 动画 / 冒险\r",
            "douban_movie_language": "英语\r",
            "douban_movie_releasetime": "2015-07-17(中国大陆) / 2015-02-06(英国)\r",
            "douban_movie_time": "85分钟\r",
            "douban_movie_othername": "小羊肖恩大电影 / 超级无敌羊咩咩大电影之咩最劲(港) / 笑笑羊大电影(台) / 超级无敌羊咩咩 电影版 / 笑笑羊 电影版\r",
            "douban_movie_url": "http://movie.douban.com/subject/24397586/?from=tag_all",
            "imdb_movie_url": "http://www.imdb.com/title/tt2872750",
            "douban_movie_imgurl": "http://img3.douban.com/view/movie_poster_cover/spst/public/p2249261202.jpg",
            "douban_movie_shortcomment": 2205,
            "douban_movie_questioncomment": null,
            "douban_movie_longcomment": 10,
            "douban_movie_talknum": null,
            "douban_movie_lookedman": 6174,
            "douban_movie_wantlookman": 10690,
            "douban_movie_score": "8.5",
            "douban_movie_scorepeople": 5389,
            "douban_5scorepercent": "43.5",
            "douban_4scorepercent": "42.0",
            "douban_3scorepercent": "13.2",
            "douban_2scorepercent": "1.0",
            "douban_1scorepercent": "0.3",
            "douban_movie_abstract": " 厌倦了每天千篇一律的枯燥生活，小羊肖恩决定做些改变。他煽动同伴们参与了他的计划，引开狗狗比泽尔的同时，将农夫催眠。可是他们的快乐假日还没开始，意外突然发生。关着农夫的拖车厢失去控制，一路向市中心冲去。比泽尔命令羊羊们回到农场，自己则惊慌失措地跑去营救农夫。好不容易醒来的农夫根本搞不清发生了什么状况，随后头部遭受撞击失去了记忆。另一边，农场在三只肥猪的祸害下沸反盈天，乱作一团。肖恩、提米、雪利他们都开始怀念一本正经的农夫了。一不做二不休，肖恩背起行囊混上了开往市中心的巴士，他的伙伴们也不打招呼尾随而至。 \r\n 怎奈城市的情况极其复杂，冷酷无情的抓狗人更成为羊羊们难以逾越的障碍……",
            "douban_movie_place": "英国 / 法国\r",
            "douban_movie_year": "2015"
        },
       ];
    var movieblocks = $(".loveType>.line>.movieblock");
    var movieName = "";
    for (var i = 0; i < lovemovies.length; i++ ){
        $(movieblocks[i]).empty();
        $(movieblocks[i]).append("<a href="+lovemovies[i].douban_movie_url+"><img src="+lovemovies[i].douban_movie_imgurl+" width='100px' height='150px'/></a>");
        movieName = lovemovies[i].douban_movie_name;
        if (movieName.length > 33) {
            movieName = movieName.substr(0, 30);
            movieName += '...';
        }
        $(movieblocks[i]).append("<p><a href="+funnymovies[i].douban_movie_url+">"+movieName+"</a></p>");
        $(movieblocks[i]).append("<a class='scoring'>"+lovemovies[i].douban_movie_score+"</a>");
    }
    movieblocks = $(".horrorType>.line>.movieblock");
    movieName = "";
    for (var i = 0; i < horrormovies.length; i++ ){
        $(movieblocks[i]).empty();
        $(movieblocks[i]).append("<a href="+horrormovies[i].douban_movie_url+"><img src="+horrormovies[i].douban_movie_imgurl+" width='100px' height='150px'/></a>");

        movieName = horrormovies[i].douban_movie_name;
        if (movieName.length > 33) {
            movieName = movieName.substr(0, 30);
            movieName += '...';
        }
        $(movieblocks[i]).append("<p><a href="+funnymovies[i].douban_movie_url+">"+movieName+"</a></p>");
        $(movieblocks[i]).append("<a class='scoring'>"+horrormovies[i].douban_movie_score+"</a>");
    }
    movieblocks = $(".funnyType>.line>.movieblock");
    movieName = "";
    for (var i = 0; i < funnymovies.length; i++ ){
        $(movieblocks[i]).empty();
        $(movieblocks[i]).append("<a href="+funnymovies[i].douban_movie_url+"><img src="+funnymovies[i].douban_movie_imgurl+" width='100px' height='150px'/></a>");
        movieName = funnymovies[i].douban_movie_name;
        if (movieName.length > 33) {
            movieName = movieName.substr(0, 30);
            movieName += '...';
        }
        $(movieblocks[i]).append("<p><a href="+funnymovies[i].douban_movie_url+">"+movieName+"</a></p>");
        $(movieblocks[i]).append("<a class='scoring'>"+funnymovies[i].douban_movie_score+"</a>");
    }


}
